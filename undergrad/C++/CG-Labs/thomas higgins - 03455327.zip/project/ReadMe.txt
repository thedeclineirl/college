Thomas Higgins - 03455327

"A walk in the park"


	Animation
The man walks around the roundabout.

	Textures
Working after much intial trouble
I have used 4 textures
-grass.ppm
-sign2.ppm
-tarmac.ppm
-leaves.ppm

	Lighting
 I couldn't get this to work at all so it has been left out for the sake of having something working


